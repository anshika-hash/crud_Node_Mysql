const express = require('express');
const app = express();
const bodyparser = require('body-parser');
const mysql = require('mysql');
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({extended :false}))
app.use(bodyParser.json())

//mysql

const users = mysql.createPool({
    connectionLimit : 20,
    host            : 'localhost',
    user            : 'root',
    database        : 'users'
})

//get all users.

app.get('',(req,res)=>{
    users.getConnection((err,connection)=>{
        if(err) throw err
        console.log(`connection as id ${connection.threadId}`)

        //query
        connection.query('SELECT * from user',(err,rows)=>{
            if(!err){
                res.send(rows)
            }else{
                console.log(err)
            }
        })
    })
})

// get a user by id

app.get('/:id',(req,res)=>{
    users.getConnection((err,connection)=>{
        if(err) throw err
        console.log(`connection as id ${connection.threadId}`)

        //find by id
        connection.query('SELECT * from user WHERE id = ?',[req.params.id],(err,rows)=>{
            if(!err){
                res.send(rows)
            }else{
                console.log(err)
            }
        })
    })
})



// delete a user by id

app.delete('/:id',(req,res)=>{
    users.getConnection((err,connection)=>{
        if(err) throw err
        console.log(`connection as id ${connection.threadId}`)

        //find by id
        connection.query('DELETE  from user WHERE id = ?',[req.params.id],(err,rows)=>{
            if(!err){
                res.send(rows)
            }else{
                console.log(err)
            }
        })
    })
})
// add a user by id

app.post('',(req,res)=>{
    users.getConnection((err,connection)=>{
        if(err) throw err
        console.log(`connection as id ${connection.threadId}`)

        const params = req.body
        connection.query('INSERT  INTO user SET ?',params,(err,rows)=>{
            if(!err){
                res.send(`${params} has been added`)
            }else{
                console.log(err)
            }
        })
        console.log(req.body)
    })
})

// update

app.put('',(req,res)=>{
    users.getConnection((err,connection)=>{
        if(err) throw err
        console.log(`connection as id ${connection.threadId}`)

        const params = req.body
        const {id, name, email} = req.body
        connection.query('UPDATE user SET name = ? WHERE id = ?',[name,id],(err,rows)=>{
            if(!err){
                res.send(`${id} has been updated`)
            }else{
                console.log(err)
            }
        })
        console.log(req.body)
    })
})

//Listen

app.listen(3000,()=>{
    console.log(`Server is running at port 3000`);
})